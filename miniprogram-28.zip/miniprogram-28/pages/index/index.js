Page({
    data: {
        dataText: '',
        Time: '',
        Tempeture: '',
        Pressure: '',
        Wet: '',
        history: '',  // New variable for storing history data
    },

    getData: function() {
        var that = this;
        wx.request({
            url: 'http://123.57.207.193:6826/getData',
            method: 'GET',
            success: function(res) {
                console.log(res);
                that.setData({
                    dataText: JSON.stringify(res.data),
                    Time: JSON.stringify(res.data.Time),
                    Tempeture: JSON.stringify(res.data.Tempeture),
                    Pressure: JSON.stringify(res.data.Pressure),
                    Wet: JSON.stringify(res.data.Wet),
                    Light: JSON.stringify(res.data.Light),
                });
            }
        });
    },

    // New function for fetching history data
    getHistory: function() {
        var that = this;
        wx.request({
            url: 'http://123.57.207.193:6826/getHistory',
            method: 'GET',
            success: function(res) {
                console.log(res);
                that.setData({
                    history: res.data
                });
            }
        });
    }
    
});
